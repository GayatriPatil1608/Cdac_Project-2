package com.app.entities;

public enum UserRoles {
	ROLE_USER, ROLE_ADMIN, ROLE_STUDENT, ROLE_TEACHER, ROLE_PARENT
}
