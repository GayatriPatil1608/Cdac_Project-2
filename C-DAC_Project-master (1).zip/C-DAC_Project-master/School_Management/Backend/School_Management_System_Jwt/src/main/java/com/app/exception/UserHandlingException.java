package com.app.exception;

public class UserHandlingException extends RuntimeException{

	public UserHandlingException(String mesg) {
		super(mesg);
	}
	
	

}
